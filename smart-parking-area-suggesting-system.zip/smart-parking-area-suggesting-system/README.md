# Smart Parking Area Suggesting System

A web application that helps drivers find, compare and book parking areas. It recommends the nearest, the most available and the cheapest parking area, shows availability on a Google Map, and lets users reserve a slot and pay online or at the parking. Parking owners can lease out spaces, and admins manage everything from a dashboard.

Built with **Python, FastAPI, PostgreSQL, HTML, CSS and JavaScript**.

## Features

**For users**
- Sign up, log in, forgot and reset password, edit profile
- Search parking areas by name or address and filter by vehicle type (Car, Bike, Truck)
- **Smart recommendations:** nearest area, most available area and best price
- Google Map with markers (green = slots available, red = full) and a directions link
- Rule-based natural-language search (for example, searching for nearby EV parking) and a parking help chatbot
- Voice search (browser speech recognition) and a language switch for English, Hindi and Marathi
- Book a slot with vehicle number, date, start and end time, and an estimated cost
- Pay online with Razorpay or choose pay at parking
- Booking confirmation, reservation history, cancel booking, and feedback after a booking
- Lease a parking space (submit lease and cancel lease) and a rule-based lease price suggestion
- Submit complaints

**For admins**
- Separate admin login
- Dashboard, reports, and lists of users and bookings
- Add, edit and delete parking areas

## Tech stack

| Layer | Technology |
|---|---|
| Backend | Python, FastAPI, Jinja2 templates |
| Database | PostgreSQL (psycopg2) |
| Frontend | HTML, CSS, JavaScript |
| Maps | Google Maps JavaScript API |
| Payments | Razorpay |
| Security | Password hashing (passlib with bcrypt), signed session cookies |

## Database tables

`users`, `parking_spots`, `bookings`, `lease`, `admin`, `feedback`

Tables are created automatically when the app starts, and sample parking areas are added the first time.

## Project structure

```
smart_park/
├── main.py            # FastAPI app and all routes
├── database.py        # Database connection, tables, queries and recommendation logic
├── auth.py            # Password hashing and token helpers
├── templates/         # Jinja2 HTML pages (user pages and admin pages)
├── static/            # Static files
├── requirements.txt
└── .env.example       # Template for your environment variables
```

## How to run locally

You need Python 3.11 or newer and a PostgreSQL database.

```bash
# 1. Clone the repository and open the folder
git clone https://github.com/<your-username>/<repository-name>.git
cd <repository-name>

# 2. Create and activate a virtual environment
python -m venv .venv
source .venv/bin/activate          # on Windows: .venv\Scripts\activate

# 3. Install the dependencies
pip install -r requirements.txt

# 4. Create your settings file and fill in your own values
cp .env.example .env               # on Windows: copy .env.example .env

# 5. Start the app
uvicorn main:app --reload
```

Open http://127.0.0.1:8000 in your browser. The admin panel is at `/admin/login`, using the `ADMIN_USERNAME` and `ADMIN_PASSWORD` from your `.env` file.

### Environment variables

| Variable | Purpose |
|---|---|
| `DATABASE_URL` | PostgreSQL connection string |
| `SESSION_SECRET` | Secret used to sign session cookies |
| `SECRET_KEY` | Secret used for tokens |
| `GOOGLE_MAPS_API_KEY` | Google Maps JavaScript API key |
| `RAZORPAY_KEY_ID`, `RAZORPAY_SECRET` | Razorpay keys (use test keys while developing) |
| `ADMIN_USERNAME`, `ADMIN_PASSWORD` | First admin account, created when the database is empty |

Never commit your real `.env` file. Restrict your Google Maps key to your own website in the Google Cloud Console.

## Notes and limitations

- The AI search and chatbot are rule-based (keyword matching), not machine learning models.
- Distance is calculated from a fixed reference point (Chakan, Pune), not the user's live location.
- Razorpay should be used in test mode while developing.
- There are no automated tests yet.

## Possible improvements

- Use the visitor's real location for distance
- Real-time availability from sensors
- Automated tests and a deployment pipeline
- Smarter ranking that combines distance, price and availability

<!-- Add screenshots here: create a docs/screenshots folder and link the images. -->
